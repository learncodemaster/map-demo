import React from 'react';
import {Home} from "./home"

function Nav(props) {
    return (
        <div>
            {/* <Home/> */}
        </div>
    );
}

export default Nav;