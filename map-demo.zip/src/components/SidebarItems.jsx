const SidebarItems = [
    {
        name: " BUS",
        route: '/'
    },
    {
        name: " CAR",
        route: '/car'
    },
    {
        name: "TRUCK",
        route: '/truck'
    },
    {
        name: "PICKUP",
        route: '/pickup'
    },
];

export default SidebarItems;